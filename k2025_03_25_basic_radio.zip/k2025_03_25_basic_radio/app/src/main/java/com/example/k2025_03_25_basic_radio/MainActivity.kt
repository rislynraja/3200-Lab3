package com.example.k2025_03_25_basic_radio

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.k2025_03_25_basic_radio.ui.theme.K2025_03_25_basic_radioTheme
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var radioIsSetUp: Boolean = false
    private var currentRadio: String = "" //  keeps track of which one its on

    private val radioStations = listOf(
        Triple("UConn Radio","http://stream.whus.org:8000/whusfm","https://brand.uconn.edu/wp-content/uploads/sites/14/2019/08/husky-logo-lockup-circleR.jpg"),
        Triple("Bolton Radio","http://radio.canstream.co.uk:8000/live.mp3","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFq4_cp2e8zCA2askoa7y-uALw8ruzoLC-0Q&s"),
        Triple("Jazz Radio","https://icecast.walmradio.com:8443/jazz","https://i.pinimg.com/736x/00/6f/e7/006fe7f785c991102866b859a4b6be7e.jpg"),
        Triple("80s Radio","https://0n-80s.radionetz.de/0n-80s.mp3","https://img.freepik.com/premium-vector/retro-vibes-revival-celebrate-classic-80s-music-with-bold-vibrant-design_585146-1166.jpg"),
        Triple("Pop Radio","https://adhandler.kissfmradio.cires21.com/get_link?url=https://bbkissfm.kissfmradio.cires21.com/bbkissfm.mp3","https://static.vecteezy.com/system/resources/thumbnails/007/379/506/small_2x/pop-music-vintage-3d-lettering-retro-bold-font-typeface-pop-art-stylized-text-old-school-style-neon-light-letters-90s-80s-poster-banner-dark-violet-color-background-vector.jpg"),
        Triple("Kpop Radio","https://antares.dribbcast.com/proxy/kpop?mp=/s","https://img.freepik.com/free-vector/k-pop-music-concept_52683-43966.jpg"),
        Triple("Country Radio","https://0n-country.radionetz.de/0n-country.mp3","https://t4.ftcdn.net/jpg/03/15/99/71/360_F_315997124_HKjCX2F8A3ln486Doc7Md3K0ulaHJvdQ.jpg"),
        Triple("Rock Radio","https://0n-classicrock.radionetz.de/0n-classicrock.mp3","https://ak1.ostkcdn.com/images/products/9075649/Rock-Music-Logo-Decor-Vinyl-Wall-Art-L16267517.jpg"),
        Triple("Hiphop Radio","https://breakz-2012-high.rautemusik.fm/?ref=radiobrowser-top100-clubcharts","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkwgznJfgCqcC8pCCuw1PXJnnAyNjlrLFWgQ&s"),
        Triple("Metal Radio","https://0n-heavymetal.radionetz.de/0n-heavymetal.mp3","https://www.shutterstock.com/image-vector/musical-drums-set-playing-silhouette-600nw-2475490693.jpg")
    )

    //@OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            K2025_03_25_basic_radioTheme {
                RadioScreen()
            }
        }
    }

    @Composable
    fun RadioScreen() {
        var volume by remember { mutableStateOf(1f) }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = "Radio!!",
            )
            LazyColumn {
                items(radioStations) {(name, url, imageURL) ->
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .clickable{ switchRadio(url)},
                        verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = imageURL,
                            contentDescription = "Logo or Image",
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .clickable {
                                    switchRadio(url)
                                }
                        )
                    }
                }
            }

            Text(text = "Volume", modifier = Modifier.padding(16.dp))
            Slider(
                value = volume,
                onValueChange = {
                    volume = it
                    setVolume(volume)
                },
                valueRange = 0f..1f,
                modifier = Modifier.padding(horizontal = 32.dp)
            )

            Row(modifier = Modifier.padding(16.dp)) {
                Button(onClick = {startRadio() }) {
                    Log.i("RFR", "Radio start");
                    Text(text = "Start Radio")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = {stopRadio()}) {
                    Log.i("RFR", "Radio stop");
                    Text(text = "Stop Radio")
                }
            }

        }
    }

    private fun switchRadio(url: String) {
        Log.i("RFR", "Switching to: $url")
        stopRadio()
        setUpRadio(url)
        currentRadio = url // for testing purposes
    }

    private fun startRadio() {
        if (radioIsSetUp) {
            Log.i("RFR", "Radio is starting")
            mediaPlayer?.start()
        }
    }

    private fun stopRadio() {
        if (radioIsSetUp) {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            radioIsSetUp = false
        }
    }

    private fun setUpRadio(url: String) {
        if (radioIsSetUp == false) {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                prepareAsync()
                setOnPreparedListener { start()}
            }
            radioIsSetUp = true // updating variable
        }
    }

    private fun setVolume(volume: Float) {
        mediaPlayer?.setVolume(volume, volume)
    }

}
